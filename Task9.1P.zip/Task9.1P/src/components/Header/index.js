import React, { Component } from 'react'
import './index.css'

export default class Header extends Component {
  render () {
    return (
      <ul className="nav-group">
        <li className="logo">ICrowdTask</li>
        <li>How it works</li>
        <li>Requesters</li>
        <li>Workers</li>
        <li>Pricing</li>
        <li>About</li>
        <li className="sign">Sign in</li>
      </ul>
    )
  }
}
