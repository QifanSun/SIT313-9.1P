import React, { Component } from 'react'
import './index.css'
import img1 from './../../assets/images/1.jpg';
import img2 from './../../assets/images/2.jpg';
import img3 from './../../assets/images/3.jpg';

export default class Footer extends Component {
  render () {
    return (
      <div className="footer">
        <div className="input-group">
          <div className="name">NEWSLETTER SIGN</div>
          <div>
            <input type="text" placeholder="Enter your email" className="email" />
          </div>
          <div>
            <button type="button" className="btn">Subscribe</button>
          </div>
        </div>
        <div className="connect">
          <div className="connect-us">CONNECT US</div>
          <div>
            <img src={img1} alt="pic1" />
          </div>
          <div>
            <img src={img2} alt="pic2" />
          </div>
          <div>
            <img src={img3} alt="pic3" />
          </div>
        </div>
      </div>
    )
  }
}
