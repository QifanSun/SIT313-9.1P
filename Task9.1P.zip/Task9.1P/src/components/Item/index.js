import React, { Component } from 'react'
import './index.css'
import skyImg from './../../assets/images/sky.jpg'

export default class Item extends Component {
  render () {
    const { index } = this.props;
    return (
      <dl className="item-group">
        <dt className="item-img">
          <img src={skyImg} alt="pic" />
        </dt>
        <dd className="item-title">Requesters's Name {index}</dd>
        <dd className="content">Description________________________________________________________________________________________</dd>
      </dl>
    )
  }
}
