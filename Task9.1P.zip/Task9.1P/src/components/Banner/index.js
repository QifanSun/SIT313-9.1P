import React, { Component } from 'react'
import './index.css'
import skyImg from './../../assets/images/sky.jpg'

export default class Banner extends Component {
  render () {
    return (
      <div className="banner">
        <img src={skyImg} alt="pic" />
      </div>
    )
  }
}
