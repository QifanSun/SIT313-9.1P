import React from 'react';
import './App.css';
import Header from './components/Header';
import Banner from './components/Banner';
import Item from './components/Item';
import Footer from './components/Footer';

function App () {
  return (
    <div className="App">
      {/* head */}
      <Header />
      <Banner />
      <div className="title">Featured Requesters</div>
      {/* list */}
      <div style={{ overflow: 'hidden' }}>
        {
          [1, 2, 3, 4, 5, 6].map((item) => {
            return <Item key={item} index={item}/>
          })
        }
      </div>
      {/* footer */}
      <Footer />
    </div>
  );
}

export default App;
